class Name(Exception):
    pass
class ID(Exception):
    pass
class Phone(Exception):
    pass

class Guest:
    def __init__(self):
        self._name=None
        self._id=None
        self._phone=None
    @property
    def name(self):
        return self._name
    @property
    def id(self):
        return self._id
    @property
    def phone(self):
        return self._phone
    @name.setter
    def name(self,name):
        if isinstance(name, str) and name:
            self._name = name
        else:
            raise Name("Name is not in String format")


    @id.setter
    def id(self,id):
        if id.isdigit():
            self._id=id
        else:
            raise ID("ID contains only digits")


    @phone.setter
    def phone(self,phone):
        if phone.isdigit() :
            self._phone=phone
        else:
            raise Phone("Phone contains only digits")



    def get_user_info(self):
        self.name = input("Enter your name: ")
        #self.id = input("Enter your ID number: ")
        self.phone = input("Enter your phone number: ")
        self.id = input("Enter your ID number: ")
    def __str__(self):
        return f"""Informations applied successfully!
***Name of Guest: {self._name.upper()}   ***
***ID number: {self._id}   ***
***Phone number:{self._phone}   ***"""

guest=Guest()
try:
    guest.get_user_info()
except Name as e:
    print(e)
except ID as e:
    print(e)
except Phone as e:
    print(e)
print(guest)