import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorUI extends JFrame {
    private JTextField display;
    private boolean isNewInput = true; // To clear input for new operations
    private double memory = 0; // To store previous number
    private String operator = ""; // To store the last operator used

    public CalculatorUI() {
        setTitle("Engineering Calculator");
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(45, 45, 45));

        // Create the display
        display = new JTextField("0");
        display.setFont(new Font("Arial", Font.BOLD, 30));
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setEditable(false);
        display.setBackground(new Color(45, 45, 45));
        display.setForeground(Color.WHITE);
        display.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(display, BorderLayout.NORTH);

        // Create buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 4, 10, 10));
        buttonPanel.setBackground(new Color(45, 45, 45));

        String[] buttons = {
                "AC", "+/-", "√", "sin",
                "cos", "tan", "π", "e",
                "7", "8", "9", "÷",
                "4", "5", "6", "×",
                "1", "2", "3", "-",
                "0", ".", "=", "+"
        };

        for (String text : buttons) {
            JButton button = new JButton(text);
            button.setFont(new Font("Arial", Font.BOLD, 20));
            button.setFocusPainted(false);
            button.setBorderPainted(false);

            if (text.matches("\\d") || text.equals(".")) {
                button.setBackground(new Color(68, 68, 68));
                button.setForeground(Color.WHITE);
            } else if (text.equals("AC") || text.equals("+/-")) {
                button.setBackground(new Color(85, 85, 85));
                button.setForeground(Color.WHITE);
            } else if (text.equals("=") || text.matches("[+\\-×÷√sin|cos|tan|π|e]")) {
                button.setBackground(new Color(255, 149, 0));
                button.setForeground(Color.WHITE);
            }

            button.addActionListener(new CalculatorButtonListener());
            buttonPanel.add(button);
        }

        add(buttonPanel, BorderLayout.CENTER);
    }

    private class CalculatorButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = ((JButton) e.getSource()).getText();

            try {
                if (command.matches("\\d|\\.")) { // Numbers or decimal
                    if (isNewInput) {
                        display.setText(command);
                        isNewInput = false;
                    } else {
                        display.setText(display.getText() + command);
                    }
                } else if (command.equals("AC")) { // Clear
                    display.setText("0");
                    memory = 0;
                    operator = "";
                    isNewInput = true;
                } else if (command.equals("+/-")) {
                    double currentValue = Double.parseDouble(display.getText());
                    display.setText(String.valueOf(-currentValue));
                } else if (command.equals("√")) { // Square root
                    double currentValue = Double.parseDouble(display.getText());
                    display.setText(String.valueOf(Math.sqrt(currentValue)));
                    isNewInput = true;
                } else if (command.equals("sin")) { // Sine function
                    double currentValue = Math.toRadians(Double.parseDouble(display.getText()));
                    display.setText(String.valueOf(Math.sin(currentValue)));
                    isNewInput = true;
                } else if (command.equals("cos")) { // Cosine function
                    double currentValue = Math.toRadians(Double.parseDouble(display.getText()));
                    display.setText(String.valueOf(Math.cos(currentValue)));
                    isNewInput = true;
                } else if (command.equals("tan")) { // Tangent function
                    double currentValue = Math.toRadians(Double.parseDouble(display.getText()));
                    display.setText(String.valueOf(Math.tan(currentValue)));
                    isNewInput = true;
                } else if (command.equals("π")) { // Pi constant
                    display.setText(String.valueOf(Math.PI));
                    isNewInput = true;
                } else if (command.equals("e")) { // 'e' constant
                    display.setText(String.valueOf(Math.E));
                    isNewInput = true;
                } else if (command.equals("=")) { // Calculate result
                    double currentValue = Double.parseDouble(display.getText());
                    switch (operator) {
                        case "+" -> memory += currentValue;
                        case "-" -> memory -= currentValue;
                        case "×" -> memory *= currentValue;
                        case "÷" -> {
                            if (currentValue != 0) {
                                memory /= currentValue;
                            } else {
                                display.setText("Error");
                                return;
                            }
                        }
                    }
                    display.setText(String.valueOf(memory));
                    isNewInput = true;
                } else { 
                    memory = Double.parseDouble(display.getText());
                    operator = command;
                    isNewInput = true;
                }
            } catch (Exception ex) {
                display.setText("Error");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            CalculatorUI calculator = new CalculatorUI();
            calculator.setVisible(true);
        });
    }
}
