from datetime import date
class OutofRange(Exception):
    pass
from random import choice

from cashtransaction import CashTransaction
from creditcard import CreditCardTransaction
from checktransaction import CheckTransaction
#from amount import Amount

class BillTransaction:
    def __init__(self, creation_date):
        self.creation_date = creation_date
        self._choice=None
    def initiate_transaction(self):
        print(self)
        while True:
            try:
                self._choice = int(input("Enter payment option:"))
                if self._choice == 1:

                    cash_tx = CashTransaction(date.today())
                    cash_tx.get_amount_info()
                    cash_tx.get_cash_info()

                    print(cash_tx)
                    break
                elif self._choice == 2:

                    credit_card = CreditCardTransaction(date.today())
                    credit_card.get_amount_info()
                    credit_card.get_bill_info()
                    print(credit_card)
                    break
                elif self._choice == 3:
                    check = CheckTransaction(date.today())
                    check.get_amount_info()
                    check.get_bank_info()

                    print(check)
                    break
                else:
                    raise OutofRange("Invalid choice. Please select a valid option.")
            except OutofRange as e:
                print(e)
            except ValueError as e:
                print(e)


    def __str__(self):
        return f"""Please select which payment option is preferable for you:
***Press 1 for cash transaction***
***Press 2 for credit card transaction***
***Press 3 for check transaction***"""

bill=BillTransaction(date.today())
bill.initiate_transaction()





