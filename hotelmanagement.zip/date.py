import datetime
from hotel import Hotel
class Month(Exception):
    pass

class Date(Hotel):
    def __init__(self,month):
        super().__init__()
        self.month=month
        self._day=None
    def current_time(self):
        self.now = datetime.datetime.now()
        return f"Current date and time:{self.now}"
    @property
    def day(self):
        return self._day
    @day.setter
    def day(self,day):
        if isinstance(day,int) and 0<=day<=30:
            self._day=day
        else:
            raise Month("\nPlease enter valid month number within 1 and 30")
    def get_day(self):
        self._day=int(input("\nHow many days you want to stay hotel:"))
        #return self._day
    def calculate_days(self):
        return (self.now+2)

    def __str__(self):
        return f"""GREAT! You want to stay hotel during {self.day} days in {self.month}.
***You will be our guest within {self.now.strftime("%A")} and {(self.now + datetime.timedelta(self._day)).strftime("%A")}***"""
d=Date("November")
print(d.current_time())

try:
    d.get_day()
except Month as e:
    print(e)
print(d)