
class dicnumber(Exception):
    pass
class Hotel(Exception):
    pass

class Hotel:
        def __init__(self):

            self._hotel=None
            self.hotel_dic={
                1:'Wyndham Tashkent',
                2:'Hilton Tashkent City',
                3:'Radisson Blu Hotel'
            }
        @property
        def hotel(self):
            return self._hotel

        @hotel.setter
        def hotel(self, hotel, hotel_dic):
            self._hotel = hotel
        def get_hotel_info(self):
            while True:
                try:
                    self._hotel = int(input("To select hotels,Please enter 1,2 or 3:  "))
                    if self._hotel==1:
                        print(self.hotel_dic[1],"is located in Amir Temur Street C4")
                        break
                    elif self._hotel==2:
                        print(self.hotel_dic[2],"is located in Ukchi Street,1")
                        break
                    elif self._hotel == 3:
                        print(self.hotel_dic[3],"is located in Amir Temur Street 88")
                        break
                    #else:
                     #   raise dicnumber("Enter valid number to select hotel!")
                except Hotel as e:
                    print("Invalid input!")

        def __str__(self):
            return f"""In your near area,top 3 hotels are available.
            1:'Wyndham Tashkent',
            2:'Hilton Tashkent City'
            3:'Radisson Blu Hotel' """

h=Hotel()
print(h)

try:
    h.get_hotel_info()
except dicnumber as e:
    print(e)
#print(h)
#print(h.hotel)
