class Not(Exception):
    pass

class Notification:
    def __init__(self):
        self._postal = None

class Cityerror(Exception):
    pass

class Staterror(Exception):
    pass

class Zipcodeerror(Exception):
    pass

class Email(Exception):
    pass

class PostalNotification(Notification):
    def __init__(self):
        self._city = None
        self._state = None
        self._zipcode = None
        super().__init__()

    @property
    def city(self):
        return self._city

    @city.setter
    def city(self, city):
        if isinstance(city, str) and city:
            self._city = city
        else:
            raise Cityerror("City should be in String format!")

    @property
    def state(self):
        return self._state

    @state.setter
    def state(self, state):
        if isinstance(state, str) and state:
            self._state = state
        else:
            raise Staterror("State should be in String format!")

    @property
    def zipcode(self):
        return self._zipcode

    @zipcode.setter
    def zipcode(self, zipcode):
        if isinstance(zipcode, int):
            self._zipcode = zipcode
        else:
            raise Zipcodeerror("Zipcode should be in Integer format!")

    def get_postal_info(self):
        try:
            self._city = input("Enter your city: ")
        except Cityerror as e:
            print(e)
            return
        try:
            self._state = input("Enter your state: ")
        except Staterror as e:
            print(e)
            return
        while True:
            self._zipcode = input("Enter your zipcode of city: ")
            try:
                self.zip = int(self._zipcode)
                break
            except ValueError:
                print("Invalid input! Please enter a number.")

    def conclusion(self):
        return f"""Ura!!! Everything is clear. Address details:
    City: {self._city.title()}
    State: {self._state.title()}
    Zipcode: {self._zipcode} 
And if you have notification, we send to this address."""

    def __str__(self):
        return "For Postal Notification, your address details are necessary!"

class EmailNotification(Notification):
    def __init__(self):
        self._email = None
        self._choice = None
        super().__init__()

    def is_valid(self):
        return "@" in self._email

    def get_email_info(self):
        while True:
            try:
                self._email = input("Sample:!!!scarletcorp@gmail.com!!!  Enter your email: ")
                if self.is_valid():
                    print("Email is valid!")
                    break
                else:
                    raise Email("Process Failed! Enter a valid email address!")
            except Email as e:
                print(e)

    def __str__(self):
        return "We send any notifications about hotel to this email."

    def notification_choice(self):
        while True:
            try:
                self._choice = int(input("Enter preferable notification option (1 for Email, 2 for Postal): "))
                if self._choice == 1:
                    self.get_email_info()
                    break
                elif self._choice == 2:
                    postal.get_postal_info()
                    break
                else:
                    raise Not("Invalid choice! Please enter 1 or 2.")
            except (Not, ValueError) as e:
                print(e)
postal=PostalNotification()

