class Amount:
    def __init__(self):
        self._amount = None

    @property
    def amount(self):
        return (self._amount)

    @amount.setter
    def amount(self, amount):
        if isinstance(amount, int) and amount > 0:
            self._amount = amount
        else:
            raise ValueError("Enter valid amount!")

    def get_amount_info(self):
        try:
            self._amount = int(input("Enter bill amount:"))
        except ValueError as e:
            print(e)
        # payment.py

