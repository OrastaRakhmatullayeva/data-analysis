class InvalidNameError(Exception):
    "Name should be in string format"
    pass
class InvalidAdress(Exception):
    "Adress should be in string format"
    pass
class InvalidPhone(Exception):
    "Phone number should be in string format"
    pass
from enum import Enum
class AccountType(Enum):
    MEMBER = "Member"
    GUEST = "Guest"
    MANAGER = "Manager"
    RECEPTIONIST="Receptionist"
class Person:
    def __init__(self):
        self._name = None
        self._address = None
        self._phone = None
    @property
    def name(self):
        return self._name
    @name.setter
    def name(self, name):
        self._name = name

    def is_valid_name(self, value):
        if value.isalpha():
            return True
        return False

    def get_person_info(self):
        while True:
            try:
                self._name = input("Enter your name: ")
                if self.is_valid_name(self._name):
                    print("Thanks!!! Your name is", self._name)
                    break
                else:
                    raise InvalidNameError("Please enter valid name!")
            except InvalidNameError as e:
                print(e)
    @property
    def address(self):
        return self._address
    @address.setter
    def address(self, address):
        self._address = address
    def is_valid_adress(self,val):
        if val.isalpha():
            return True
        return False
    def get_address_info(self):
        while True:
            try:
                self._address=input("Enter your adress:")
                if self.is_valid_adress(self._address):
                    print("Your current location:",self._address)
                    break
                else:
                    raise InvalidAdress("Invalid address!")
            except InvalidAdress as e:
                print(e)
            #except ValueError("Invalid Adress!")
    @property
    def phone(self):
        return self._phone
    @phone.setter
    def phone(self,phone):
        self._phone=phone
    def is_valid_phone(self,number):
        if number.isdigit() and len(number)==9:
            return True
        return False
    def get_phone_info(self):
        while True:
            try:
                self._phone=input("Enter your phone number:+998")
                if self.is_valid_phone(self._phone):
                    print("Your phone number is +998",self._phone)
                    break
                else:
                    raise InvalidPhone("Invalid phone number!Please enter exactly 9 digits")
            except InvalidPhone as e:
                print(e)
            except ValueError as e:
                print(e)
    def __str__(self):
        return f"""Infos taken successfully!
    Name:{self._name}
    Current Address:{self._address}
    Phone Number:{self._phone}"""




# Example usage
person = Person()
person.get_person_info()
person.get_address_info()
person.get_phone_info()
print(person)