from tkinter.font import names

#from guest import Guest

class Name(Exception):
    pass
class Description(Exception):
    pass
class Server:
    def __init__(self):

        self.amenities=[]

    def add_Room_Charge(self):
        return True

    def add_amenity(self, amenity):
        self.amenities.append(amenity)

class Amenity(Server):
    def __init__(self):
        super().__init__()
        self.amenities=[]
        self._name=None
        self._description=None

        self.amenity_list={
            "High - Speed Wi - Fi":"Reliable and fast Wi-Fi is crucial for work or leisure.",
            "Comfortable Bedding":"High-quality mattresses, fresh linens, and plush pillows.",
            "Flat-Screen TV":"A TV with local and cable channels .",
            "Mini Fridge":"A small fridge lets guests store leftovers, drinks, or medications.",
            "Air Conditioning and Heating":"Temperature control makes comfortable in any weather."
        }

    def add_room_service(self, room_service):
        self.room_services.append(room_service)

    def add_kitchen_service(self, kitchen_service):
        self.kitchen_services.append(kitchen_service)
    def get_Amenity(self):
        print("These top 5 amenities!")
        for self.key,self.value in self.amenity_list.items():
            print(f"{self.key}:{self.value}")

        print("IF you want another amenity,Please enter name and description:")
        self._name=input("\nPlease Enter amenity name you want:")
        self._description=input("\nPlease Enter short description of amenity:")

    @property
    def name(self):
        return self._name
    @name.setter
    def name(self,name):
        if isinstance(name, str) and name:
            self._name = name
        else:
            raise Name("Name should be in String format")
    @property
    def description(self):
        return self._description
    @description.setter
    def description(self,description):
        if isinstance(description, str) and description:
            self._description = description
        else:
            raise Description("Description should be in String format")
    def __str__(self):
        return f"\nService you want is added to management system"

amenity=Amenity()
amenity.get_Amenity()
print(amenity)




