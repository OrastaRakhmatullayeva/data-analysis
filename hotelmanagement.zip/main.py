class dicnumber(Exception):
    pass
class room(Exception):
    pass
class roomnumber(Exception):
    pass
class InvalidNameError(Exception):
    "Name should be in string format"
    pass
class InvalidAdress(Exception):
    "Adress should be in string format"
    pass
class InvalidPhone(Exception):
    "Phone number should be in string format"
    pass
import datetime

class Month(Exception):
    pass
class Name(Exception):
    pass
class Description(Exception):
    pass
class Cityerror(Exception):
    pass
class Staterror(Exception):
    pass
class Zipcodeerror(Exception):
    pass
class Email(Exception):
    pass
from datetime import date

from account import Account
from hotel import Hotel
from room import Room
from date import Date
from person import Person
from server import Amenity
from payment import BillTransaction
from notification import EmailNotification
from notification import PostalNotification
if __name__=="__main__":
    while True:
#account
        account = Account()
        print(account)
        account.get_account()

#hotel
        h = Hotel()
        print(h)
        try:
            h.get_hotel_info()
        except dicnumber as e:
            print(e)
#room
        r = Room()
        r.get_room_number()
        print(r)
        try:
            r.get_room_info()
        except room as e:
            print(e)
#date
        d = Date("November")
        print(d.current_time())

        try:
            d.get_day()
        except Month as e:
            print(e)
        print(d)
#person
        person = Person()
        person.get_person_info()
        person.get_address_info()
        person.get_phone_info()
        print(person)
#payment
        bill = BillTransaction(date.today())
        bill.initiate_transaction()
#amenity
        amenity = Amenity()
        amenity.get_Amenity()
        print(amenity)
#notification
        postal = PostalNotification()
        email = EmailNotification()
        email.notification_choice()
        print(postal.conclusion())

        continue_choice = input("Do you want to enter information for another booking? (YES/NO): ").strip().upper()
        if continue_choice != "YES":
            print("Exiting the program. Thank you!")
            break

