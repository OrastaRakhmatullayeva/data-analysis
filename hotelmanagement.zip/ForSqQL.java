/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package forsqql;
import java.sql.*;
import java.util.Scanner;


/**
 *
 * @author asus
 */
public class ForSqQL {
      //private static final String url = "jdbc:mysql://localhost:3306/BMI_DB";
    private static final String url = "jdbc:mysql://localhost:3306/world";
       private static final String username = "root"; // Replace with your MySQL username
      private static final  String password = "Orasta3172302";// Replace with your MySQL password
    public static void main(String[] args) {
        
        
      
        System.out.println("Choose an operation:");
        System.out.println("1. Insert: ");
        System.out.println("2. View :");
        System.out.println("3. Delete :");
        System.out.println("4. Update :");
        
     Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        if (choice == 1) {
            insertRecord(scanner);
        } else if (choice == 2) {
            viewRecords();
        } else if (choice == 3) {
            deleteRecord(scanner);
        } else if (choice == 4) {
            updateRecord(scanner);
        } else {
            System.out.println("Not valid option!");
        }
    }
    
    //methods
    //1. Method to insert a new record into the BMI table
    private static void insertRecord(Scanner scanner) {
        System.out.print("Enter person id : ");
        int personID = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character
        System.out.print("Enter person name: ");
        String personName = scanner.nextLine();
        System.out.print("Enter weight : ");
        int weight = scanner.nextInt();
        System.out.print("Enter height : ");
        int height = scanner.nextInt();
        String query = "INSERT INTO BMI (PersonID, PersonName, Weight, Height) VALUES (?, ?, ?, ?)";
        
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, personID);
            statement.setString(2, personName);
            statement.setInt(3, weight);
            statement.setInt(4, height);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Record inserted successfully.");
            } else {
                System.out.println("Failed to insert record.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    
    //another method 
// Method to view all records from the BMI table
    private static void viewRecords() {
        String query = "SELECT * FROM BMI";
        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            System.out.println("\n--- BMI Records ---");
            while (resultSet.next()) {
                int personID = resultSet.getInt("PersonID");
                String personName = resultSet.getString("PersonName");
                int weight = resultSet.getInt("Weight");
                int height = resultSet.getInt("Height");

                System.out.printf("ID: %d, Name: %s, Weight: %d, Height: %d\n", personID, personName, weight, height);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    // Method to delete a record based on PersonID
    private static void deleteRecord(Scanner scanner) {
        System.out.print("Enter PersonID to delete: ");
        int personID = scanner.nextInt();