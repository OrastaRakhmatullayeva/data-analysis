class InvalidIDError(Exception):
    "ID should be in integer format containing only 4 digits"
    pass
class InvalidPas(Exception):
    pass

from enum import Enum
class AccountStatus(Enum):
    ACTIVE = "Active"
    CLOSED = "Closed"
    CANCELLED = "Cancelled"
    BLACKLISTED="Blacklisted"

class Account:
    def __init__(self):
        self._id=None
        self._password=None
        self._acc=None
        self.status = AccountStatus.ACTIVE
    @property
    def id(self):
        return self._id
    @id.setter
    def id(self,id):
        self._id=id
    def is_active(self,value):
        if value.isdigit() and len(value)==4:
            return True
        return False

    def get_id_info(self):
        while True:
            try:
                self._id=input("Enter your ID number with 4 digits:")
                if self.is_active(self._id):
                    print("""GREAT!!!Your ID is valid
One step to login to account""")
                    break
                else:
                    raise ValueError("Invalid ID!")
            except ValueError as e:
                print(e)
            except InvalidIDError as e:
                print(e)
    @property
    def password(self):
        return self._password
    @password.setter
    def password(self,password):
        self._password=password
    def is_valid_password(self,password):
        if password.isdigit() and len(password)==4:
            return True
        return False
    def get_pas_info(self):
        while True:
            try:
                self._password=input("Enter your password with 4 digits:")
                if self.is_valid_password(self._password):
                    print("""Congratulations.
***Your password is correct.Account Status is""",self.status.value,
"""\nWELCOME TO OUR HOTEL!!!""")
                    break
                else:
                    raise ValueError("Invalid password!")
            except InvalidPas as e:
                print(e)
            except ValueError as e:
                print(e)
    def get_account(self):
        while True:
            try:
                self._acc = input("Do you have an account already? (YES/NO):")
                if (self._acc).upper()=="YES":
                    self.get_id_info()
                    self.get_pas_info()
                    break
                elif (self._acc).upper()=="NO":
                    print("""GREAT!!!TO use our Hotel Service System, 
***you should enter 4 digit number as your ID number.
***Please make sure ID should be strong and secure.""")
                    self.get_id_info()
                    self.get_pas_info()
                    break
                else:
                    raise InvalidIDError("Invalid input!")
            except InvalidIDError as e:
                print(e)

    def __str__(self):
        return f"""Welcome to HOTEL MANAGEMENT SYSTEM.
Thanks for choosing our service)"""


account=Account()
print(account)
account.get_account()