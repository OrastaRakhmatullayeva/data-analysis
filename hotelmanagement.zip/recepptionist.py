class Receptionist:
    def __init__(self):
        self._receptionist=None

    def createBooking(self):
        return True
