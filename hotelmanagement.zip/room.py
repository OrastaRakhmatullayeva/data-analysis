class room(Exception):
    pass
class roomnumber(Exception):
    pass
class Room:
    def __init__(self):
        self._room=None
        #Room Style, Booking Price,
        self.price_dic={
            'Standard':136,
            'Deluxe':256,
            'Premium':475
        }
        self._number=None
    @property
    def room(self):
        return self._room
    @room.setter
    def room(self,room):
        self._room=room
    @property
    def number(self):
        return self._number
    @number.setter
    def number(self,number):
        self._number=number
    def isAvailable(self):
        if self._number in range(200,250):
            return True
        else:
            return False

    def get_room_info(self):
        while True:
            try:
                self._room=int(input("To select room style,Please enter 1,2 or 3:  "))
                if self._room==1:
                    print("For Standard Room,the price per day is ",self.price_dic['Standard'],'$')
                    break
                elif self._room==2:
                    print("For Deluxe Room,the price per day is ", self.price_dic['Deluxe'],'$')
                    break
                elif self._room==3:
                    print("For Premium Room,the price per day is ", self.price_dic['Premium'],"$")
                    break
                else:
                    raise room("Please select valid room style!")
                break
            except ValueError as e:
                print(e)
    def get_room_number(self):
        while True:
            try:
                self._number=int(input("Searching process of room number.Enter room number:"))
                if self.isAvailable():
                    print(self._number,"- room is available!")
                    break
                else:
                    print("Oops!",self._number,'- room is unavailable!')
                    raise roomnumber("Please enter only between 200-250!")
            except roomnumber as e:
                print(e)
            except ValueError:
                print("Invalid input! Please enter a number.")

    # if isinstance(self._number,int) and 200<=self._number<=250:
        #    print("Room is valid!")
        #else:
         #   raise roomnumber("Please enter only between 200-250!")

    def __str__(self):
        return f"""Please select room style:Standart/Deluxe/Premium
 ***For Standart,press 1***
 ***For Deluxe,  press 2***
 ***For Premium, press 3***"""

r=Room()
r.get_room_number()
print(r)
try:
    r.get_room_info()
except room as e:
    print(e)



