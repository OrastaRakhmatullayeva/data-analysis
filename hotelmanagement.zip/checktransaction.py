from datetime import date
from enum import Enum
#from payment import BillTransaction
class PaymentStatus(Enum):
    PENDING = "Pending"
    COMPLETED = "Completed"
    FAILED = "Failed"

from amount import Amount
class CheckTransaction(Amount):
    def __init__(self, creation_date):
        super(Amount).__init__()
        self._bank_name = None
        self.creation_date = creation_date
        self._check_number = None
        self.status = PaymentStatus.PENDING
    @property
    def bank_name(self):
        return self._bank_name
    @bank_name.setter
    def bank_name(self,bank_name):
        if isinstance(bank_name,str) and bank_name:
            self._bank_name=bank_name
        else:
            raise ValueError("Enter valid name of bank!")
    @property
    def check_number(self):
        return self._check_number
    @check_number.setter
    def check_number(self,check_number):
        if isinstance(check_number,int) and check_number:
            self._check_number=check_number
        else:
            raise ValueError("Enter valid check number!")
    def get_bank_info(self):
        try:
            self._bank_name = input("Enter name of bank:")
        except ValueError as e:
            print(e)
        try:
            self._check_number=int(input("Enter check number:"))
        except ValueError as e:
            print(e)
    def __str__(self):
        return f"""Infos token successfully!Transaction on {self.creation_date}:
         Your total amount:{self._amount}
         Name of bank: {self._bank_name}, 
         Check number: {self._check_number},
         Status: {self.status.value}"""
#check= CheckTransaction(date.today() )
#check.get_bank_info()
#print(check)