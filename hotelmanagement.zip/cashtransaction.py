from datetime import date
#from payment import BillTransaction
from enum import Enum
class PaymentStatus(Enum):
    PENDING = "Pending"
    COMPLETED = "Completed"
    FAILED = "Failed"

from amount import Amount
class CashTransaction(Amount):
    def __init__(self, creation_date):
        super(Amount).__init__()
        self.creation_date=creation_date
        self._cash_tendered = None
        self.status = PaymentStatus.PENDING
    @property
    def cash_tendered(self):
        return self._cash_tendered
    @cash_tendered.setter
    def cash_tendered(self,cash_tendered):
        if isinstance(cash_tendered,int) and cash_tendered>0:
            self._cash_tendered=cash_tendered
        else:
            raise ValueError("Enter valid amount!")
    def get_cash_info(self):
        try:
            self._cash_tendered=int(input("Enter cash tendered:"))
        except ValueError as e:
            print(e)
    def __str__(self):
        return f"""Infos token successfully!Transaction on {self.creation_date}:
        Your total amount:{self._amount} 
        Cash tendered: {self._cash_tendered},
        Status: {self.status.value}"""

