from datetime import date
from enum import Enum
#from payment import BillTransaction
class PaymentStatus(Enum):
    PENDING = "Pending"
    COMPLETED = "Completed"
    FAILED = "Failed"

from amount import Amount
class CreditCardTransaction(Amount):
    def __init__(self, creation_date):
        super(Amount).__init__()
        self.creation_date = creation_date
        self._name_on_card = None
        self._zip_code = None
        self.status = PaymentStatus.PENDING
    @property
    def name_on_card(self):
        return self._name_on_card
    @name_on_card.setter
    def name_on_card(self,name_on_card):
        if isinstance(name_on_card,str) and name_on_card:
            self._name_on_card=name_on_card
        else:
            raise ValueError("Enter valid amount!")

    @property
    def  zip_code(self):
        return self._zip_code
    @zip_code.setter
    def zip_code(self, zip_code):
        if isinstance( zip_code,int) and  zip_code>0:
            self._zip_code= zip_code
        else:
            raise ValueError("Enter valid amount!")

    def get_bill_info(self):
        try:
            self._name_on_card = input("Enter name on card:")
        except ValueError as e:
            print(e)
        try:
            self._zip_code=int(input("Enter zip-code:"))
        except ValueError as e:
            print(e)
    def __str__(self):
        return f"""Infos token successfully!Transaction on {self.creation_date}:
        Your total amount:{self._amount} 
        Name on card: {self._name_on_card}, 
        Zip code: {self._zip_code},
        Status: {self.status.value}"""


#credit_card = CreditCardTransaction(date.today())
#credit_card.get_bill_info()
#print(credit_card)